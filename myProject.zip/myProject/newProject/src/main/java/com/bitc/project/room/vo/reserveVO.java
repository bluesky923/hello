package com.bitc.project.room.vo;

public class reserveVO {

}
